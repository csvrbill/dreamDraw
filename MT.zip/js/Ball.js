// JavaScript Document
var Ball = function()
{
}